#include "menu.h"
#include "food_ordering_data_declare.h"
#include <sstream>
#include <format>
#include <iostream>
#include <iomanip>

void MenuItem::importMenuDatabase(FileManager& menu_file)
{
	std::string menu_database = menu_file.getFileContent();
	std::stringstream ss(menu_database);
	std::string token;
	uint32_t food_number{ 0 };
	while (std::getline(ss, token, '\n'))
	{
		auto colon_pos_1 = token.find(':');
		auto colon_pos_2 = token.find_last_of(':');
		if ((colon_pos_1 == std::string::npos) || (colon_pos_2 == std::string::npos))
		{
			continue;
		}
		FoodInfo temp;
		++food_number;
		temp.food_number = food_number;
		temp.food_name = token.substr(0, colon_pos_1);
		temp.price = std::stoi((token.substr(colon_pos_1 + 1, colon_pos_2)));
		temp.quanity = std::stoi(token.substr(colon_pos_2 + 1, token.length() - 1));
		this->MenuItemList.push_back(temp);
	}
}

void MenuItem::printAllFood() const
{
	for(FoodInfo temp : this->MenuItemList)
	{
		std::cout << std::setw(10)	<< std::right	<< temp.food_number << ") ";
		std::cout << std::setw(15)	<< std::left	<< temp.food_name;
		std::cout << std::setw(8)	<< std::left	<< temp.price;
		std::cout << "VND" << std::endl;
	}
	return;
}

std::string MenuItem::getFoodName(int& food_number)
{
	for(auto food : this->MenuItemList)
	{
		if(food.food_number == food_number)
		{
			return food.food_name;
		}
	}
	return "";
}

int MenuItem::getFoodPrice(int& food_number) const
{
	for (auto food : this->MenuItemList)
	{
		if (food.food_number == food_number)
		{
			return food.price;
		}
	}
	return 0;
}


void MenuItem::orderAdd(struct Order orders)
{
	FoodInfo temp;
	temp.food_number = orders.food_number;
	temp.quanity = orders.quanity;
	temp.food_name = this->getFoodName(orders.food_number);
	temp.price = this->getFoodPrice(orders.food_number);
	this->Order.push_back(temp);
}

void MenuItem::showOrder()
{
	int sum{ 0 };
	std::cout << "\033[36m";
	std::cout << std::left << std::setw(15) << "FOOD_NAME";
	std::cout << std::left << std::setw(13) << "QUANTITY";
	std::cout << std::left << std::setw(12) << "UNIT_PRICE";
	std::cout << std::left << std::setw(8) << "TOTAL";
	std::cout << std::endl;
	std::cout << "-----------------------------------------------\n";
	for(auto order : this->Order)
	{
		std::cout << std::left << std::setw(15) << order.food_name;
		std::cout << std::left << std::setw(13) << order.quanity;
		std::cout << std::left << std::setw(12) << order.price;
		std::cout << std::left << std::setw(8) << order.quanity * order.price;
		std::cout << std::endl;
		sum = sum + order.quanity * order.price;
	}
	std::cout << "\n-----------------------------------------------\n";
	std::cout << "\033[1mTotal due: ";
	std::cout << std::right << std::setw(35) << sum << "\n\n";
	std::cout << "\033[0m";
}

void MenuItem::orderComplete()
{
	this->order_state = true;
}

bool MenuItem::isOrdered()
{
	return this->order_state;
}





