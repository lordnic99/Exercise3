#ifndef FOOD_ORDERING_DATA_DECLARE_H

#define FOOD_ORDERING_DATA_DECLARE_H

#include <string>
typedef struct UserAccount
{
	std::string user_name{};
	std::string password{};
} UserAccount;

typedef struct FoodInfo
{
	uint32_t food_number{};
	std::string food_name{};
	uint32_t price{};
	uint32_t quanity{};
} FoodInfo;

typedef struct Order
{
	int food_number{};
	int quanity{};
} Order;
#endif
