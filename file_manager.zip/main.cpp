#include <iostream>
#include <format>
#include <string>
#include <fstream>
#include "file_manager.h"
#include "user_account.h"
#include "menu.h"
#include "food_ordering_data_declare.h"


void systemInit(FileManager& registed_file, FileManager& menu_file, Account& user_account, MenuItem &menu)
{
	registed_file.getFileName("RegisteredInfo.txt");
	menu_file.getFileName("Menu.txt");
	user_account.importDatabase(registed_file);
	menu.importMenuDatabase(menu_file);
}

void registerFoodOrdering(Account &user_account, FileManager &registed_file)
{
	std::string user_name{}, password{};
	do
	{
		std::cout << "\033[1;33m\033[3mEnter username: \033[0m";
		std::cin.ignore();
		std::getline(std::cin, user_name);
		//std::cin >> user_name;
	} while ((!user_account.userNameLegalCheck(user_name) || (!user_account.userNameDuplicateCheck(user_name))));
	std::cout << "\033[1;33m\033[3mEnter password: \033[0m";
	fflush(stdin);
	std::getline(std::cin, password);
	//std::cin >> password;
	user_account.userRegister(user_name, password, registed_file);
}

void loginFoodOrdering(Account& user_account)
{
	std::string user_name{}, password{};
	std::cout << "\033[1;33m\033[3mEnter username: \033[0m";
	std::cin.ignore();
	std::getline(std::cin, user_name);
	std::cout << "\033[1;33m\033[3mEnter password: \033[0m";
	fflush(stdin);
	std::getline(std::cin, password);
	user_account.userLogin(user_name, password);
}

void logoutFoodOrdering(Account &user_accout)
{
	user_accout.userLogout();
}

bool isUserLogin(Account& user_account)
{
	return user_account.isLogin();
}

bool checkUserFunctionChoiceOnFirstScreen(int &fuction_choice)
{
	if((fuction_choice < 1) || (fuction_choice > 3))
	{
		return false;
	}
	return true;
}
void printFirstScreen()
{
	system("cls");
	std::cout << "\033[1;33m***************** Welcome To My Food Ordering System *****************\033[0m\n\n\n";
	std::cout << "\033[1;34m\t\t1. Login\033[0m\n";
	std::cout << "\033[1;34m\t\t2. Register\033[0m\n";
	std::cout << "\033[1;34m\t\t3. Exit\033[0m\n\n\n";
}

void printSecondScreen(Account &user_account, MenuItem &menu)
{
	system("cls");
	std::cout << "\033[1;33m***************** Food Ordering System *****************\033[0m\n\n\n\n";
	std::cout << std::format("\033[1;36mWelcome back: {}\033[0m\n\n", user_account.getUserName());
	std::cout << "--------------------------------------------------------\n\n\n";
	std::cout << "\033[1;32m";
	menu.printAllFood();
}


int main()
{
	FileManager registed_file;
	FileManager menu_file;
	Account user_account;
	MenuItem menu;
	systemInit(registed_file, menu_file, user_account , menu);
	int user_function_choice{ 0 };
	bool goToScreenTwo{ false };
	while(true)
	{
		if(goToScreenTwo)
		{
			break;
		}
		switch (user_function_choice)
		{
		case 0:
			{
				printFirstScreen();
				do
				{
					std::cout << "What is your choice: ";
					std::cin >> user_function_choice;
				} while (!checkUserFunctionChoiceOnFirstScreen(user_function_choice));
				break;
			}
		case 1:
			{
				system("cls");
				std::cout << "\033[1;31m******* Login Screen *******\n\n\033[0m";
				loginFoodOrdering(user_account);
				if (isUserLogin(user_account))
				{
					goToScreenTwo = true;
					std::cout << "\n\033[1;33mLogin Successful! Thank you!\033[0m";
					std::cin.get();
				}
				else
				{
					std::cerr << "\n\033[1;33mYour account does not exist!\n";
					std::cout << "Would you to register a new account: (y/n) \033[0m";
					char response;
					std::cin.get(response);
					response = toupper(response);
					user_function_choice = response == 'Y' ? (2) : (0);
				}
				break;
			}
		case 2:
			{
				system("cls");
				std::cout << "\033[1;31m******* Register Screen *******\n\n\033[0m";
				registerFoodOrdering(user_account,registed_file);
				if(isUserLogin(user_account))
				{
					goToScreenTwo = true;
				}
				std::cout << "\n\033[1;33mRegistration Successful! Thank you!\033[0m";
				std::cin.get();
				break;
			}
		case 3:
			{
				std::cout << "Are you sure you want to exit: (y/n) ";
				char response;
				std::cin.ignore();
				std::cin.get(response);
				response = toupper(response);
				if (response == 'Y')
				{
					exit(0);
				}
				else
				{
					user_function_choice = 0;
				}
			}
		}
	}

	user_function_choice = 0;
	int food_choice{ -1 };
	std::vector<Order> orders{};
	while(goToScreenTwo)
	{
		switch (user_function_choice)
		{
		case 0:
			{
				printSecondScreen(user_account, menu);
				std::cout << "\n\n\033[0mEnter 0 for place order, -1 for exit!\n";
				std::cout << "Enter you choice: ";
				std::cin >> food_choice;
				if((food_choice != 0) && (food_choice != -1) && (!menu.isOrdered()))
				{
					std::cout << std::format("You select {}\n", menu.getFoodName(food_choice));
					std::cout << std::format("What is the quanity: ");
					int quanity{};
					std::cin >> quanity;
					Order temp;
					temp.food_number = food_choice;
					temp.quanity = quanity;
					menu.orderAdd(temp);
					std::cout << "Food was add!\n";
					std::cout << "Press any key to continue!\n";
					std::cin.ignore();
					std::cin.get();
				}
				else if (food_choice == -1)
				{
					exit(0);
				}
				else if (menu.isOrdered())
				{
					std::cout << "You have already order!\n";
					user_function_choice = 0;
				}
				else
				{
					user_function_choice = 1;
				}
				break;
			}
		case 1:
			{
				system("cls");
				menu.showOrder();
				std::cout << "Would you like to place order (y/n): ";
				char response;
				std::cin.ignore();
				std::cin.get(response);
				response = toupper(response);
				if (response == 'Y')
				{
					std::cout << "Order success, thanks for supporting us!";
					menu.orderComplete();
				}
				else
				{
					user_function_choice = 0;
				}
				break;
			}
		}

	}
	return 0;
}


