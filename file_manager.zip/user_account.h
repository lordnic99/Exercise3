#ifndef USER_ACCOUNT_H

#define USER_ACCOUNT_H

#include <string>
#include "file_manager.h"
#include <list>
#include "food_ordering_data_declare.h"

class Account
{
public:
	Account() = default;
	void userLogin(const std::string& user_name, const std::string& password);
	void userRegister(const std::string& use_name, const std::string& password, FileManager& data_file);
	void userLogout();
	void importDatabase(FileManager& data_file);
	bool isLogin();
	bool userNameDuplicateCheck(std::string& user_name) const;
	bool userNameLegalCheck(std::string& user_name) const;
	std::string getUserName() { return  this->user_name; }
private:
	std::string user_name{}, password{};
	std::list <UserAccount> UserAccountDataBase{};
	bool isLoginVar{ false };
};

#endif
