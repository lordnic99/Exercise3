#ifndef ACCOUNT_H_

#define ACCOUNT_H_

#include <string>

class Account
{
public:
	Account() : user_name(""), password(""), isLogin(false) {};
	void getUserDataBase(std::string &data_base);
	void getUserLogin();
	void getUserRegister();
	void UserLogin();
	void UserRegister();
	bool isLogin{false};
	inline static std::string user_database{ "" };
private:
	std::string user_name{""};
	std::string password{ "" };
	bool isLegal(std::string user_name);
	std::string getString();
};

#endif // !ACCOUNT_H_

