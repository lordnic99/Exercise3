#include "iostream"
#include "account.h"
#include <string>

std::string Account::getString()
{
	std::string string_to_get{};
	std::getline(std::cin, string_to_get);
	return string_to_get;
}

bool Account::isLegal(std::string user_name)
{
    for (std::size_t i = 0; i < user_name.length(); i++)
    {
        if ((user_name[i] >= 48 && user_name[i] <= 57) ||
            (user_name[i] >= 65 && user_name[i] <= 90) ||
            (user_name[i] >= 97 && user_name[i] <= 122))
        {
            continue;
        }
        else
        {
            return false;
        }
    }
    return true;
}

void Account::getUserRegister()
{
    do
    {
        std::cout << "Allow number and alphabet characters only!";
        std::cout << "Enter username: ";
        this->user_name = getString();
    } while (!isLegal(user_name));
    std::cout << "Enter password: ";
    this->password = getString();
    return;
}

void Account::getUserLogin()
{
	std::cout << "Enter username: ";
    this->user_name = getString();
    std::cout << "Enter password: ";
    this->password = getString();
}

void Account::getUserDataBase(std::string &data_base)
{
    Account::user_database = data_base;
    return;
}

void Account::UserRegister()
{
    std::string new_user_create = '\n' + this->user_name + ':' + this->password;
    Account::user_database += new_user_create;
    this->isLogin = true;
}


void Account::UserLogin()
{
    std::string user_check = this->user_name + ':' + this->password;
    auto login_check = Account::user_database.find(user_check);
    if(login_check == std::string::npos)
    {
        this->isLogin = false;
    }
    else
    {
        this->isLogin = true;
    }
    return;
}



