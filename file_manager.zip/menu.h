#ifndef MENU_H

#define MENU_H

#include <vector>
#include "food_ordering_data_declare.h"
#include "file_manager.h"

class MenuItem
{
public:
	void importMenuDatabase(FileManager& menu_file);
	void printAllFood() const;
	void orderAdd(Order order);
	std::string getFoodName(int& food_number);
	int getFoodPrice(int& food_number) const;
	void showOrder();
	void orderComplete();
	bool isOrdered();
private:
	std::vector<FoodInfo> MenuItemList{};
	std::vector<FoodInfo> Order{};
	bool order_state{ false };
};

#endif