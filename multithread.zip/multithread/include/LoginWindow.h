#ifndef LOGIN_WINDOW_H

#define LOGIN_WINDOW_H

#include <gtkmm.h>
#include <string>

class LoginWindow : public Gtk::Window  {
public:
  LoginWindow();
  std::string getUserName();
  std::string getUserPassword();
  void closeLoginWindows();
  bool isLoginButtonClicked();
private:
  Gtk::Entry *m_username_entry;
  Gtk::Entry *m_password_entry;
  void clickedLoginButton();
  void clickedRegiserButton();
  void loginFailedDialog();
  bool is_login_button_clicked{false};
};

#endif // !DEBUG
