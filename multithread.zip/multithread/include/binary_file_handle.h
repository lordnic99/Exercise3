#ifndef BINARY_FILE_HANDLE_H

#define BINARY_FILE_HANDLE_H

#include <map>
#include <string>

//Only support binary file with map<string,string> type

class BinaryHandler
{
    private:
    std::string file_location{};
    public:
    BinaryHandler(std::string file_name) : file_location(file_name) {};
    void setFileLocation(std::string file_name);
    std::map<std::string,std::string> getData();
};


#endif // !BINARY_FILE_HANDLE_H
