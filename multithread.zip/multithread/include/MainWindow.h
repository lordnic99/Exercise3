#ifndef MAIN_WINDOW_H

#define MAIN_WINDOW_H

#include <gtkmm.h>


class MainWindow : public Gtk::Window  {
public:
  MainWindow();

private:
  void on_deposited_clicked();
  void on_withdrawn_clicked();

};

#endif
