#include "../include/LoginWindow.h"
#include <string>
#include <iostream>

LoginWindow::LoginWindow() {
  set_title("Login Screen");
  set_border_width(10);

  // Create login form
  Gtk::Box *vbox = Gtk::manage(new Gtk::Box(Gtk::ORIENTATION_VERTICAL, 10));
  Gtk::Label *username_label = Gtk::manage(new Gtk::Label("Username:"));
  m_username_entry = Gtk::manage(new Gtk::Entry());
  Gtk::Label *password_label = Gtk::manage(new Gtk::Label("Password:"));
  m_password_entry = Gtk::manage(new Gtk::Entry());
  m_password_entry->set_visibility(false);
  Gtk::Button *login_button = Gtk::manage(new Gtk::Button("Login"));
  login_button->signal_clicked().connect(
      sigc::mem_fun(*this, &LoginWindow::clickedLoginButton));
  Gtk::Button *register_button = Gtk::manage(new Gtk::Button("Register"));
  register_button->signal_clicked().connect(
      sigc::mem_fun(*this, &LoginWindow::clickedRegiserButton));

  // Add widgets to vbox
  vbox->pack_start(*username_label, Gtk::PACK_SHRINK);
  vbox->pack_start(*m_username_entry, Gtk::PACK_SHRINK);
  vbox->pack_start(*password_label, Gtk::PACK_SHRINK);
  vbox->pack_start(*m_password_entry, Gtk::PACK_SHRINK);
  vbox->pack_start(*login_button, Gtk::PACK_SHRINK);
  vbox->pack_start(*register_button, Gtk::PACK_SHRINK);

  add(*vbox);
  show_all_children();
}

void LoginWindow::clickedRegiserButton() {

  Gtk::MessageDialog dialog("Sorry!", false, Gtk::MESSAGE_QUESTION,
                            Gtk::BUTTONS_OK_CANCEL, true);
  dialog.set_secondary_text(
      "Sorry, register on this app was not available right now!");
  dialog.run();
}

void LoginWindow::clickedLoginButton() {
  
}

std::string LoginWindow::getUserName() {
  return m_username_entry->get_text();
  
}
std::string LoginWindow::getUserPassword() {
  return m_password_entry->get_text();
}

bool LoginWindow::isLoginButtonClicked()
{
  return this->is_login_button_clicked;
}

void LoginWindow::loginFailedDialog() {
  Gtk::MessageDialog dialog("Failed!", false, Gtk::MESSAGE_QUESTION,
                            Gtk::BUTTONS_OK_CANCEL, true);
  dialog.set_secondary_text(
      "Failed to login, please check your infomation!");
  dialog.run();
}

void LoginWindow::closeLoginWindows()
{
  hide();
}