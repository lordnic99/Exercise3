#include "../include/binary_file_handle.h"
#include <fstream>
#include <iostream>

void BinaryHandler::setFileLocation(std::string file_name) {
  this->file_location = file_name;
}

std::map<std::string, std::string> BinaryHandler::getData() {
  std::ifstream data_file(this->file_location, std::ios::binary);
  if (!data_file) {
    std::cout << "Error opening file\n";
    exit(1);
  }
  std::map<std::string, std::string> data_read;
  while (!data_file.eof()) {
    int keySize, valueSize;
    data_file.read(reinterpret_cast<char *>(&keySize), sizeof(keySize));
    if (data_file.eof())
      break;
    char *key = new char[keySize];
    data_file.read(key, keySize);
    data_file.read(reinterpret_cast<char *>(&valueSize),
                        sizeof(valueSize));
    char *value = new char[valueSize];
    data_file.read(value, valueSize);
    data_read[std::string(key, keySize)] = std::string(value, valueSize);
    delete[] key;
    delete[] value;
  }
  data_file.close();
  return data_read;
}