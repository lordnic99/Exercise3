#include "../include/LoginWindow.h"
#include <fstream>
#include <iostream>
#include <map>
#include <thread>

void startLoginScreen(LoginWindow login_window) {
  auto login_screen = Gtk::Application::create("com.example.login");
  
  login_window.set_default_size(300, 600);
  login_screen->run(login_window);
}


int main() {
  LoginWindow login_window;
  startLoginScreen(login_window);
  // while(!GlobalScope::login_window.isLoginButtonClicked())
  // {
  //   GlobalScope::user_name = GlobalScope::login_window.getUserName();
  //   GlobalScope::password = GlobalScope::login_window.getUserPassword();
  // }
  // std::cout << GlobalScope::user_name << std::endl;
  // std::cout << GlobalScope::password << std::endl;
  while (true) {
    for (int i = 0; i < 22222222; i++)
      ;
    std::cout << "This is main thread!\n";
  }
  // if (thread_login_window.joinable()) {
  //   thread_login_window.join();
  // }

  return 0;
}
