#include <iostream>
#include <format>
#include <string>
#include <fstream>
#include <typeinfo>
#include "file_manager.h"
#include "user_account.h"
#include "menu.h"
#include "food_ordering_data_declare.h"


#define GO_TO_MAIN_SCREEN		0
#define GO_TO_LOGIN_SCREEN		1
#define GO_TO_REGISTER_SCREEN	2
#define GO_TO_EXIT				3

namespace Variable
{
	int user_function_choice{ GO_TO_MAIN_SCREEN };	// store the select function by user;
	bool goToScreenTwo{ false };	// if true go to the next screen;
	bool goToScreenOne{ false };	// if true go to the first screen;
	int food_choice{ -1 };			// user for selecting food;
	std::vector<Order> orders{};	// temporary store order infomation from user;
}


/**
 * This function read data from RegisteredInfo.txt, Menu.txt and put them into object.
 * 
 * \param registed_file		-> RegisteredInfo.txt file pointer
 * \param menu_file			-> Menu.txt file pointer
 * \param user_account		-> user management object
 * \param menu				-> menu management object
 */
void systemInit(FileManager& registed_file, FileManager& menu_file, Account& user_account, MenuItem &menu)
{
	registed_file.getFileName("RegisteredInfo.txt");
	menu_file.getFileName("Menu.txt");
	user_account.importDatabase(registed_file);
	menu.importMenuDatabase(menu_file);
}

/**
 * Get username, and password from user, then call userRegister method for a register.
 * 
 * \param user_account		-> 
 * \param registed_file		-> RegisteredInfo.txt file pointer for writting register infomation to file after register complete
 */
void registerFoodOrdering(Account &user_account, FileManager &registed_file)
{
	std::string user_name{}, password{};
	do
	{
		std::cout << "\033[1;33m\033[3mEnter username: \033[0m";
		std::cin.ignore();
		std::getline(std::cin, user_name);
		//std::cin >> user_name;
	} while ((!user_account.userNameLegalCheck(user_name) || (!user_account.userNameDuplicateCheck(user_name))));
	std::cout << "\033[1;33m\033[3mEnter password: \033[0m";
	fflush(stdin);
	std::getline(std::cin, password);
	//std::cin >> password;
	user_account.userRegister(user_name, password, registed_file);
}

/**
 * Get username, and password from user, then call userLogin method for login.
 * 
 * \param user_account		->
 */
void loginFoodOrdering(Account& user_account)
{
	std::string user_name{}, password{};
	std::cout << "\033[1;33m\033[3mEnter username: \033[0m";
	std::cin.ignore();
	std::getline(std::cin, user_name);
	std::cout << "\033[1;33m\033[3mEnter password: \033[0m";
	fflush(stdin);
	std::getline(std::cin, password);
	user_account.userLogin(user_name, password);
}

/**
 * Just call the logout method from user management object.
 * 
 * \param user_accout		->
 */
void logoutFoodOrdering(Account &user_accout)
{
	user_accout.userLogout();
}

/**
 * Just call the isLogin method from user management object.
 * 
 * \param user_account		->
 * \return 
 */
bool isUserLogin(Account& user_account)
{
	return user_account.isLogin();
}

/**
 * On first screen we allow only from 1-3, this function here check if the input
 * is out of range.
 * 
 * \param fuction_choice	->
 * \return 
 */
bool checkUserFunctionChoiceOnFirstScreen(int &fuction_choice)
{
	if((fuction_choice < 1) || (fuction_choice > 3))
	{
		return false;
	}
	return true;
}

/**
 * Use for login, register and exit.
 * 
 */
void printFirstScreen()
{
	system("cls");
	std::cout << "\033[1;33m***************** Welcome To My Food Ordering System *****************\033[0m\n\n\n";
	std::cout << "\033[1;34m\t\t1. Login\033[0m\n";
	std::cout << "\033[1;34m\t\t2. Register\033[0m\n";
	std::cout << "\033[1;34m\t\t3. Exit\033[0m\n\n\n";
}

/**
 * User when login is complete, print all the infomation user for ordering food
 * 
 * \param user_account
 * \param menu
 */
void printSecondScreen(Account &user_account, MenuItem &menu)
{
	system("cls");
	std::cout << "\033[1;33m***************** Food Ordering System *****************\033[0m\n\n\n\n";
	std::cout << std::format("\033[1;36mWelcome back: {}\n", user_account.getUserName());
	std::cout << "--------------------------------------------------------\n\n\n";
	std::cout << "\033[1;32m";
	menu.printAllFood();
}

template <class T> 
T getUserResponse(T &var)
{
	//std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
	std::cin >> var;
	if (typeid(var) == typeid(char))
	{
		var = toupper(var);
	}
	return var;
}

/** Do nothing, just wait user pressing a key */
void waitForUserPressAnykey()
{
	std::cin.ignore();
	std::cin.get();
}

int main()
{
	/** Object create */
	FileManager registed_file;
	FileManager menu_file;
	Account user_account;
	MenuItem menu;

	/** Initalized object */
	systemInit(registed_file, menu_file, user_account , menu);

	/** First screen */
	while(true)
	{

		/** Only go here when user login success, or register sucess */
		if(Variable::goToScreenTwo)
		{
			break;
		}

		switch (Variable::user_function_choice)
		{
			/** Case 0 is use print the menu screen when we first run the program */
		case GO_TO_MAIN_SCREEN:
			{
				printFirstScreen();
				do
				{
					std::cout << "What is your choice: ";
					Variable::user_function_choice = getUserResponse(Variable::user_function_choice);
				} while (!checkUserFunctionChoiceOnFirstScreen(Variable::user_function_choice));
				break;
			}

			/** This case will prompt the login screen */
		case GO_TO_LOGIN_SCREEN:
			{
				system("cls");

				std::cout << "\033[1;31m******* Login Screen *******\n\n\033[0m";
				loginFoodOrdering(user_account);

				if (isUserLogin(user_account))
				{
					Variable::goToScreenTwo = true;
					std::cout << "\n\033[1;33mLogin Successful! Thank you!\033[0m";
					std::cin.get();
				}

				else
				{
					std::cerr << "\n\033[1;33mYour account does not exist!\n";
					std::cout << "Would you to register a new account: (y/n) \033[0m";
					char response = getUserResponse(response);
					Variable::user_function_choice = response == 'Y' ? (2) : (0);
				}
				break;
			}

			/** This case will prompt the register screen */
		case GO_TO_REGISTER_SCREEN:
			{
				system("cls");
				std::cout << "\033[1;31m******* Register Screen *******\n\n\033[0m";

				registerFoodOrdering(user_account,registed_file);

				if(isUserLogin(user_account))
				{
					Variable::goToScreenTwo = true;
				}
				std::cout << "\n\033[1;33mRegistration Successful! Thank you!\033[0m";
				std::cin.get();
				break;
			}

			/** Prompt exit notification */
		case GO_TO_EXIT:
			{
				std::cout << "Are you sure you want to exit: (y/n) ";
				char response;
				response = getUserResponse(response);

				if (response == 'Y')
				{
					exit(0);
				}
				else
				{
					Variable::user_function_choice = 0;
				}
			}
		}
	}

	/** Reset user_function_choice variable */
	Variable::user_function_choice = GO_TO_MAIN_SCREEN;




	
	while(Variable::goToScreenTwo)
	{

		switch (Variable::user_function_choice)
		{
			
		case 0:
			{
				printSecondScreen(user_account, menu);

				std::cout << "\n\n\033[0mEnter 0 for place order, -1 if you want to exit!\n";
				std::cout << "Enter you choice: ";

				Variable::food_choice = getUserResponse(Variable::food_choice);

				if((Variable::food_choice != 0) && (Variable::food_choice != -1))
				{
					std::cout << std::format("You select {}\n", menu.getFoodName(Variable::food_choice));
					std::cout << std::format("What is the quanity: ");
					int quanity{};
					std::cin >> quanity;
					Order temp;
					temp.food_number = Variable::food_choice;
					temp.quanity = quanity;
					menu.orderAdd(temp);
					std::cout << "Food was add!\n";
					std::cout << "Press any key to continue!\n";
					waitForUserPressAnykey();
				}
				else if (Variable::food_choice == -1)
				{
					std::cout << "Are you sure you want to exit: (y/n) ";
					char response;
					response = getUserResponse(response);

					if (response == 'Y')
					{
						exit(0);
					}
					else
					{
						Variable::user_function_choice = 0;
					}
				}
				else
				{
					Variable::user_function_choice = 1;
				}

				break;
			}
		case 1:
			{
				system("cls");
				menu.showOrder();
				std::cout << "Would you like to place order (y/n): ";
				char response;
				std::cin.ignore();
				std::cin.get(response);
				response = toupper(response);
				if (response == 'Y')
				{
					std::cout << "Order success, thanks for supporting us!";
					menu.orderComplete();
					menu.resetOrder();
					Variable::user_function_choice = 0;
					waitForUserPressAnykey();
				}
				else
				{
					Variable::user_function_choice = 0;
				}
				break;
			}

		}
	}
	return 0;
}


