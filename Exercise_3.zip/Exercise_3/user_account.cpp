#include "user_account.h"
#include <string>
#include "file_manager.h"
#include "food_ordering_data_declare.h"
#include <sstream>

/**
 * Get content from a file, then put it into List.
 * 
 * \param data_file
 */
void Account::importDatabase(FileManager& data_file)
{
	std::string file_data = data_file.getFileContent();

	std::stringstream ss(file_data);
	std::string token;
	while (std::getline(ss, token, '\n'))
	{
		auto colon_pos = token.find(':');
		if(colon_pos == std::string::npos)
		{
			continue;
		}
		UserAccount temp;
		temp.user_name = token.substr(0, colon_pos);
		temp.password = token.substr(colon_pos + 1, token.length() - 1);
		UserAccountDataBase.push_back(temp);
	}
}

void Account::userLogin(const std::string& user_name, const std::string& password)
{
	this->user_name = user_name;
	this->password = password;
	for (UserAccount temp : this->UserAccountDataBase)
	{
		if ((temp.user_name == this->user_name) && (temp.password == this->password))
		{
			this->isLoginVar = true;
			return;
		}
	}
}

void Account::userRegister(const std::string& use_name, const std::string& password, FileManager& data_file)
{
	this->user_name = use_name;
	this->password = password;
	UserAccount temp;
	temp.user_name = use_name;
	temp.password = password;
	UserAccountDataBase.push_back(temp);
	data_file.writeToFile('\n' + use_name + ':' + password);
	this->isLoginVar = true;
	return;
}

void Account::userLogout()
{
	this->user_name = "";
	this->password = "";
	this->isLoginVar = false;
}

bool Account::isLogin()
{
	return this->isLoginVar;
}

bool Account::userNameDuplicateCheck(std::string& user_name) const
{
	for (UserAccount temp : UserAccountDataBase)
	{
		if (temp.user_name == user_name)
		{
			std::cerr << "Username have already exist!\n";
			return false;
		}
	}
	return true;
}

bool Account::userNameLegalCheck(std::string& user_name) const
{
	for (std::size_t i = 0; i < user_name.length(); i++)
	{
		if ((user_name[i] >= 48 && user_name[i] <= 57) ||
			(user_name[i] >= 65 && user_name[i] <= 90) ||
			(user_name[i] >= 97 && user_name[i] <= 122))
		{
			continue;
		}
		else
		{
			std::cerr << "User contain number and character only!\n";
			return false;
		}
	}
	return true;
}
